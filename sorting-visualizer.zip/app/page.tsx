"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { AlgorithmVisualizer } from "./components/algorithm-visualizer"
import { CodeView } from "./components/code-view"
import { ComplexityView } from "./components/complexity-view"
import { generateRandomArray } from "./lib/utils"
import { ArrayCustomization } from "./components/array-customization"
import CopyrightInfo from "./components/copyright-info"

export default function SortingVisualizer() {
  const [arrays, setArrays] = useState<{ [key: string]: number[] }>(() => {
    const initialSize = 10
    return {
      bubble: generateRandomArray(initialSize),
      selection: generateRandomArray(initialSize),
      insertion: generateRandomArray(initialSize),
      merge: generateRandomArray(initialSize),
      quick: generateRandomArray(initialSize),
      heap: generateRandomArray(initialSize),
    }
  })
  const [speed, setSpeed] = useState(500)
  const [arraySize, setArraySize] = useState(10)
  const [selectedAlgorithms, setSelectedAlgorithms] = useState<string[]>(["bubble"])
  const [isRunning, setIsRunning] = useState(false)

  const algorithms = [
    { id: "bubble", name: "Bubble Sort" },
    { id: "selection", name: "Selection Sort" },
    { id: "insertion", name: "Insertion Sort" },
    { id: "merge", name: "Merge Sort" },
    { id: "quick", name: "Quick Sort" },
    { id: "heap", name: "Heap Sort" },
  ]

  const handleGenerateNewArray = () => {
    if (!isRunning) {
      const newArrays: typeof arrays = {}
      Object.keys(arrays).forEach((key) => {
        newArrays[key] = generateRandomArray(arraySize)
      })
      setArrays(newArrays)
    }
  }

  const handleAlgorithmToggle = (algorithmId: string) => {
    setSelectedAlgorithms((prev) => {
      if (prev.includes(algorithmId)) {
        return prev.filter((id) => id !== algorithmId)
      } else {
        return [...prev, algorithmId]
      }
    })
  }

  const handleArrayUpdate = (newArray: number[]) => {
    if (!isRunning) {
      const newArrays: typeof arrays = {}
      Object.keys(arrays).forEach((key) => {
        newArrays[key] = [...newArray]
      })
      setArrays(newArrays)
      setArraySize(newArray.length)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-indigo-800 to-blue-900 p-4">
      <div className="max-w-7xl mx-auto pt-8 pb-16">
        <div className="text-center mb-12 animate-fade-in">
          <h1 className="text-5xl font-bold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500">
            Sorting Algorithm Visualizer
          </h1>
          <p className="text-xl text-purple-100 max-w-2xl mx-auto">
            Explore, compare and understand how different sorting algorithms work with this interactive visualization
            tool
          </p>
        </div>

        <Card className="p-8 border-none shadow-2xl bg-gradient-to-b from-gray-900/90 to-gray-900/95 backdrop-blur-sm rounded-2xl border border-gray-800">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-700">
              <label className="text-sm font-medium mb-2 block text-purple-200">Speed (ms): {speed}</label>
              <Slider
                value={[speed]}
                onValueChange={(value) => setSpeed(value[0])}
                min={50}
                max={1000}
                step={50}
                disabled={isRunning}
                className="py-4"
              />
              <div className="flex gap-2 mt-6">
                <Button
                  variant="destructive"
                  onClick={handleGenerateNewArray}
                  disabled={isRunning}
                  className="bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700 border-none"
                >
                  Generate New Array
                </Button>
              </div>
            </div>

            <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-700">
              <h2 className="text-lg font-semibold mb-4 text-purple-200">Select Algorithms</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {algorithms.map((algo) => (
                  <div key={algo.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={algo.id}
                      checked={selectedAlgorithms.includes(algo.id)}
                      onCheckedChange={() => handleAlgorithmToggle(algo.id)}
                      disabled={isRunning}
                      className="border-purple-400 text-purple-500"
                    />
                    <label
                      htmlFor={algo.id}
                      className="text-sm font-medium leading-none text-purple-200 peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      {algo.name}
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-purple-500">
              Array Customization
            </h2>
            <ArrayCustomization onArrayUpdate={handleArrayUpdate} disabled={isRunning} />
          </div>

          <Tabs defaultValue="visualization" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-gray-800/70 p-1 rounded-xl">
              <TabsTrigger
                value="visualization"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-indigo-600 data-[state=active]:text-white rounded-lg"
              >
                Visualization
              </TabsTrigger>
              <TabsTrigger
                value="code"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-indigo-600 data-[state=active]:text-white rounded-lg"
              >
                Code
              </TabsTrigger>
              <TabsTrigger
                value="complexity"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-indigo-600 data-[state=active]:text-white rounded-lg"
              >
                Complexity
              </TabsTrigger>
            </TabsList>
            <TabsContent value="visualization" className="mt-6">
              <AlgorithmVisualizer
                arrays={arrays}
                speed={speed}
                selectedAlgorithms={selectedAlgorithms}
                isRunning={isRunning}
                setIsRunning={setIsRunning}
              />
            </TabsContent>
            <TabsContent value="code" className="mt-6">
              <CodeView algorithm={selectedAlgorithms[0]} />
            </TabsContent>
            <TabsContent value="complexity" className="mt-6">
              <ComplexityView algorithm={selectedAlgorithms[0]} />
            </TabsContent>
          </Tabs>
        </Card>
      </div>
      {/* Add the CopyrightInfo component here */}
      <CopyrightInfo />
    </div>
  )
}
