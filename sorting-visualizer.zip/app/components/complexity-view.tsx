"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface ComplexityViewProps {
  algorithm: string
}

const complexityData: Record<string, { time: string; space: string }> = {
  bubble: { time: "O(n²)", space: "O(1)" },
  selection: { time: "O(n²)", space: "O(1)" },
  insertion: { time: "O(n²)", space: "O(1)" },
  merge: { time: "O(n log n)", space: "O(n)" },
  quick: { time: "O(n log n)", space: "O(log n)" },
  heap: { time: "O(n log n)", space: "O(1)" },
}

export function ComplexityView({ algorithm }: ComplexityViewProps) {
  const complexity = complexityData[algorithm]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader className="pb-2">
          <CardTitle className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">
            Time Complexity
          </CardTitle>
        </CardHeader>
        <CardContent className="text-gray-300">
          <div className="space-y-4">
            <div className="p-3 bg-gray-900/60 rounded-lg border border-gray-700">
              <span className="font-medium text-yellow-400">Worst case:</span> {complexity.time}
            </div>
            <div className="p-3 bg-gray-900/60 rounded-lg border border-gray-700">
              <span className="font-medium text-yellow-400">Average case:</span> {complexity.time}
            </div>
            <div className="p-3 bg-gray-900/60 rounded-lg border border-gray-700">
              <span className="font-medium text-yellow-400">Best case:</span>{" "}
              {algorithm === "bubble" || algorithm === "insertion" ? "O(n)" : complexity.time}
            </div>
          </div>
        </CardContent>
      </Card>
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader className="pb-2">
          <CardTitle className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-500">
            Space Complexity
          </CardTitle>
        </CardHeader>
        <CardContent className="text-gray-300">
          <div className="p-3 bg-gray-900/60 rounded-lg border border-gray-700">
            <span className="font-medium text-blue-400">Worst case:</span> {complexity.space}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
