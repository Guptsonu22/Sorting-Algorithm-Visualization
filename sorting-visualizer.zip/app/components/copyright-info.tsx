import { Linkedin, Github } from "lucide-react"

export default function CopyrightInfo() {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-white">
      <p className="text-6xl font-extrabold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-500 to-indigo-500 drop-shadow-xl tracking-tight">
        Sonu Kumar
      </p>
      <div className="flex space-x-6 mb-4">
        <a
          href="https://www.linkedin.com/in/sonu-kumar-443803231/"
          target="_blank"
          rel="noopener noreferrer"
          className="text-gray-300 hover:text-blue-400 transition-colors duration-300"
          aria-label="LinkedIn Profile"
        >
          <Linkedin size={32} />
        </a>
        <a
          href="https://github.com/Guptsonu22"
          target="_blank"
          rel="noopener noreferrer"
          className="text-gray-300 hover:text-gray-100 transition-colors duration-300"
          aria-label="GitHub Profile"
        >
          <Github size={32} />
        </a>
      </div>
      <p className="text-lg text-gray-200 tracking-widest uppercase">{"@2025 All Rights Reserved"}</p>
    </div>
  )
}
