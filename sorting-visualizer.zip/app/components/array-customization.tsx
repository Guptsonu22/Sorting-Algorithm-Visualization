"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { generateRandomArray, generateReversedArray, generateNearlySortedArray, parseManualInput } from "../lib/utils"

interface ArrayCustomizationProps {
  onArrayUpdate: (newArray: number[]) => void
  disabled?: boolean
}

const ARRAY_PRESETS = {
  small: 10,
  medium: 50,
  large: 100,
}

export function ArrayCustomization({ onArrayUpdate, disabled }: ArrayCustomizationProps) {
  const [arraySize, setArraySize] = useState<keyof typeof ARRAY_PRESETS>("small")
  const [manualInput, setManualInput] = useState("")
  const [error, setError] = useState("")
  const [currentArray, setCurrentArray] = useState(() => generateRandomArray(ARRAY_PRESETS.small))

  const updateArray = (newArray: number[]) => {
    setCurrentArray(newArray)
    onArrayUpdate(newArray)
    setError("")
  }

  const handleSizeChange = (newSize: keyof typeof ARRAY_PRESETS) => {
    setArraySize(newSize)
    updateArray(generateRandomArray(ARRAY_PRESETS[newSize]))
  }

  const handleManualInput = () => {
    const parsedArray = parseManualInput(manualInput)
    if (parsedArray) {
      updateArray(parsedArray)
    } else {
      setError("Invalid input. Please enter comma-separated numbers.")
    }
  }

  const handleGenerateArray = (type: "random" | "reversed" | "nearlySorted") => {
    const size = ARRAY_PRESETS[arraySize]
    let newArray: number[]

    switch (type) {
      case "random":
        newArray = generateRandomArray(size)
        break
      case "reversed":
        newArray = generateReversedArray(size)
        break
      case "nearlySorted":
        newArray = generateNearlySortedArray(size)
        break
      default:
        newArray = generateRandomArray(size)
    }

    updateArray(newArray)
  }

  return (
    <div className="space-y-6 p-6 bg-gray-800/50 rounded-xl border border-gray-700">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label className="text-purple-200">Array Size Preset</Label>
          <Select
            value={arraySize}
            onValueChange={(value: keyof typeof ARRAY_PRESETS) => handleSizeChange(value)}
            disabled={disabled}
          >
            <SelectTrigger className="bg-gray-900/60 border-gray-700 text-purple-200">
              <SelectValue placeholder="Select array size" />
            </SelectTrigger>
            <SelectContent className="bg-gray-900 border-gray-700">
              <SelectItem value="small">Small (10 elements)</SelectItem>
              <SelectItem value="medium">Medium (50 elements)</SelectItem>
              <SelectItem value="large">Large (100 elements)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label className="text-purple-200">Generate Array</Label>
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              onClick={() => handleGenerateArray("random")}
              disabled={disabled}
              className="bg-transparent border-purple-500 text-purple-200 hover:bg-purple-900/30 hover:text-purple-100"
            >
              Random
            </Button>
            <Button
              variant="outline"
              onClick={() => handleGenerateArray("reversed")}
              disabled={disabled}
              className="bg-transparent border-purple-500 text-purple-200 hover:bg-purple-900/30 hover:text-purple-100"
            >
              Reversed
            </Button>
            <Button
              variant="outline"
              onClick={() => handleGenerateArray("nearlySorted")}
              disabled={disabled}
              className="bg-transparent border-purple-500 text-purple-200 hover:bg-purple-900/30 hover:text-purple-100"
            >
              Nearly Sorted
            </Button>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <Label className="text-purple-200">Manual Input (comma-separated numbers)</Label>
        <div className="flex gap-2">
          <Input
            value={manualInput}
            onChange={(e) => setManualInput(e.target.value)}
            placeholder="Example: 5, 2, 8, 1, 9"
            disabled={disabled}
            className="bg-gray-900/60 border-gray-700 text-purple-200 placeholder:text-gray-500"
          />
          <Button
            onClick={handleManualInput}
            disabled={disabled}
            className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 border-none"
          >
            Apply
          </Button>
        </div>
        {error && <p className="text-sm text-red-400">{error}</p>}
      </div>

      <div className="space-y-2">
        <Label className="text-purple-200">Current Array Preview</Label>
        <div className="p-4 bg-gray-900/60 rounded-lg border border-gray-700 overflow-x-auto">
          <div className="flex gap-1 flex-wrap">
            {currentArray.map((num, i) => (
              <span
                key={i}
                className="inline-flex items-center justify-center w-8 h-8 text-sm border border-purple-700/50 rounded bg-gray-800/80 text-purple-200"
              >
                {num}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
