"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { getAlgorithmCode } from "../lib/algorithm-code"

interface CodeViewProps {
  algorithm: string
}

export function CodeView({ algorithm }: CodeViewProps) {
  const languages = ["c", "cpp", "java", "python", "javascript"]

  return (
    <Tabs defaultValue="cpp" className="w-full">
      <TabsList className="grid w-full grid-cols-5 bg-gray-800/70 p-1 rounded-xl">
        {languages.map((lang) => (
          <TabsTrigger
            key={lang}
            value={lang}
            className="capitalize data-[state=active]:bg-gradient-to-r data-[state=active]:from-cyan-600 data-[state=active]:to-blue-600 data-[state=active]:text-white rounded-lg"
          >
            {lang === "cpp" ? "C++" : lang}
          </TabsTrigger>
        ))}
      </TabsList>
      {languages.map((lang) => (
        <TabsContent key={lang} value={lang}>
          <pre className="p-6 rounded-lg bg-gray-900/80 border border-gray-700 overflow-x-auto text-gray-300">
            <code>{getAlgorithmCode(algorithm, lang)}</code>
          </pre>
        </TabsContent>
      ))}
    </Tabs>
  )
}
