interface PerformanceMetricsProps {
  comparisons: number
  swaps: number
  elapsedTime: number
  algorithm: string
}

export function PerformanceMetrics({ comparisons, swaps, elapsedTime, algorithm }: PerformanceMetricsProps) {
  return (
    <div className="grid grid-cols-3 gap-4 p-4 bg-gray-900/60 rounded-lg border border-gray-700">
      <div className="text-center">
        <div className="text-2xl font-bold text-yellow-400">{comparisons}</div>
        <div className="text-sm text-gray-400">Comparisons</div>
      </div>
      <div className="text-center">
        <div className="text-2xl font-bold text-green-400">{swaps}</div>
        <div className="text-sm text-gray-400">Swaps</div>
      </div>
      <div className="text-center">
        <div className="text-2xl font-bold text-blue-400">{elapsedTime.toFixed(2)}s</div>
        <div className="text-sm text-gray-400">Time</div>
      </div>
    </div>
  )
}
